package com.tcptest1Server;

public class MyServerSocket {
    public static void main(String[] args) {

        new ServerListener().start();
    }
}
