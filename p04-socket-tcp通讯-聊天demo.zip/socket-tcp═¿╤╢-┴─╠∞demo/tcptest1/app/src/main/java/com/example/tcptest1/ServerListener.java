package com.example.tcptest1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerListener extends Thread {

    @Override
    public void run() {
        //port:1-65535
        try{
            ServerSocket serverSocket = new ServerSocket(123456);
            //block
            Socket socket=serverSocket.accept();
            //连接

            //将socket传递给新的线程；
            ChatSocket cs = new ChatSocket(socket);
            cs.start();
            ChatManager.getChatManager().add(cs);   //将该socket线程加入到管理集合中；
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
