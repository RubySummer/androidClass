package com.example.tcptest1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class ChatSocket extends Thread {

    Socket socket;
    public ChatSocket(Socket s){
        this.socket = s;
    }

    /*
    //这个传输有点复杂，可能存在卡住的问题；
    @Override
    public void run(){
        try {
            //socket.getOutputStream();    //这个socket的输出流，只有通过输出流才能输出数据；
            BufferedWriter bw =
                    new BufferedWriter(
                            new OutputStreamWriter(
                                    socket.getOutputStream()));
            int count =0;
            while(true){
                bw.write("loop:"+count);
                sleep(1000);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }*/

    //方法二
    //数据流的写出；
    public void out(String out){
        try {
            socket.getOutputStream().write(out.getBytes("UTF-8"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        try {
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(
                            socket.getInputStream(),"UTF-8"
                    )
            );
            String line = null;
            while((line=br.readLine())!=null){
                ChatManager.getChatManager().publish(this,line);
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
